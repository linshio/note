import { ElementUIComponent } from './component'

/** Main Component */
export declare class ElMain extends ElementUIComponent {}
