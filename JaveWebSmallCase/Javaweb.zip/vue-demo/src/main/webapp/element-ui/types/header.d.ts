import { ElementUIComponent } from './component'

/** Header Component */
export declare class ElHeader extends ElementUIComponent {
  /** Height of the header */
  height: string
}
