import { ElementUIComponent } from './component'

/** Aside Component */
export declare class ElAside extends ElementUIComponent {
  /** Width of the side section */
  width: string
}
